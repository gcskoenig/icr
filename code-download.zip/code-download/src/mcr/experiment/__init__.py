from mcr.experiment.compile import compile_experiments
from mcr.experiment.run import run_experiment